---
name: opc-baijiahao-publisher
description: OPC孵化器专属百家号内容发布技能。自动读取文章文件，精简内容至百家号要求格式，生成封面图，并发布到百度百家号。触发词：发布到百家号、百家号发布、OPC百家号发布、发布文章到百家号。适用于帝苏OPC项目的营销推广内容自动化发布到百度内容生态。
---

# OPC百家号发布器

自动化完成从文章文件到百度百家号发布的完整流程。

## 执行流程

### Step 1：读取文章文件

支持格式：`.txt` 或 `.md` 文件

从用户处获取文件路径，读取内容。若未提供路径，询问用户。

### Step 2：内容适配

百家号要求：
- 标题：≤30字（建议20-28字，利于SEO）
- 正文：无严格字数上限，但建议1500-3000字为佳
- 封面图：支持单图/三图/大图模式
- 分类：需选择合适的频道分类

**精简/优化策略：**
1. 保留核心信息：产品名称、价格、效果数据
2. 增加SEO关键词：OPC、产业咨询、AI数字化、企业服务
3. 优化段落结构：小标题 + 短段落，提升阅读体验
4. 添加相关话题标签

检查字数：
```bash
python3 -c "import json; d=json.load(open('/tmp/publish_args.json')); print(f'Title: {len(d[\"title\"])} chars\nContent: {len(d[\"content\"])} chars')"
```

### Step 3：生成封面图

调用封面生成技能（disu1）生成百家号规格封面：

```bash
# 百家号封面尺寸：900x500（单图）或 300x200（三图模式）
python3 /root/.openclaw/workspace/skills/opc-baijiahao-publisher/scripts/generate_cover.py \
  "OPC孵化器" "产业咨询到AI落地" /root/.openclaw/workspace/opc_baijiahao_cover.png
```

若Pillow可用，使用备用方案：
```python
python3 << 'EOF'
from PIL import Image, ImageDraw, ImageFont
img = Image.new('RGB', (900, 500), color='#2932e1')
draw = ImageDraw.Draw(img)
try:
    font = ImageFont.truetype('/usr/share/fonts/truetype/wqy/wqy-zenhei.ttc', 60)
except:
    font = ImageFont.load_default()
draw.text((450, 220), 'OPC孵化器', fill='white', font=font, anchor='mm')
draw.text((450, 300), '产业咨询 · AI落地', fill='#e8e8e8', font=font, anchor='mm')
img.save('/root/.openclaw/workspace/opc_baijiahao_cover.png')
EOF
```

### Step 4：登录状态管理与Cookie管理

#### 4.1 检查登录状态

```bash
python3 /root/.openclaw/workspace/skills/opc-baijiahao-publisher/scripts/cookie_manager.py check
```

#### 4.2 启动浏览器登录

```bash
# 启动浏览器（带远程调试）
/root/.cache/ms-playwright/chromium-1208/chrome-linux64/chrome \
  --no-sandbox --remote-debugging-port=9223 \
  --headless=new --disable-gpu --user-data-dir=/root/.config/baijiahao-chrome &

# 导航到百家号登录页
browser action=navigate, url="https://baijiahao.baidu.com", target=host, profile=openclaw
```

#### 4.3 扫码登录流程

```bash
# 截图登录页二维码
browser action=screenshot, target=host
# 发送给用户扫码（百度App扫码）
```

等待用户扫码后验证：
```bash
browser action=snapshot, target=host
# 检查是否跳转到 https://baijiahao.baidu.com/builder/preview
```

#### 4.4 保存Cookie

登录成功后保存Cookie：
```bash
python3 /root/.openclaw/workspace/skills/opc-baijiahao-publisher/scripts/cookie_manager.py save "$(browser action=act, kind=evaluate, fn='document.cookie', target=host)"
```

### Step 5：发布到百家号

构建发布参数：
```json
{
  "title": "OPC孵化器完整产品矩阵：从产业咨询到AI落地",
  "content": "完整文章内容（HTML或Markdown）",
  "cover_image": "/root/.openclaw/workspace/opc_baijiahao_cover.png",
  "category": "企业服务",
  "tags": ["OPC孵化器", "产业咨询", "AI数字化", "企业服务", "创业孵化"],
  "cover_type": "single"
}
```

执行发布（使用浏览器自动化）：
```bash
# 1. 打开发布页面
browser action=navigate, url="https://baijiahao.baidu.com/builder/content/publish", target=host

# 2. 输入标题
browser action=act, kind=click, ref="标题输入框", target=host
browser action=act, kind=type, text="文章标题", target=host

# 3. 输入正文（切换到HTML模式或Markdown模式）
browser action=act, kind=click, ref="内容编辑区", target=host
browser action=act, kind=type, text="$(cat /tmp/article_content.html)", target=host

# 4. 上传封面图
browser action=act, kind=click, ref="上传封面", target=host
# 使用文件上传功能

# 5. 选择分类
browser action=act, kind=click, ref="分类选择", target=host
browser action=act, kind=click, ref="企业服务", target=host

# 6. 添加标签
browser action=act, kind=click, ref="添加标签", target=host
browser action=act, kind=type, text="OPC孵化器", target=host
browser action=act, kind=press, key="Enter", target=host

# 7. 发布
browser action=act, kind=click, ref="发布", target=host
```

### Step 6：验证发布结果

检查是否跳转到文章列表页或显示"发布成功"：
```bash
browser action=snapshot, target=host
```

获取文章链接：
```bash
browser action=act, kind=evaluate, fn="window.location.href", target=host
```

## Cookie管理脚本

使用 `scripts/cookie_manager.py` 管理登录态：

| 命令 | 功能 |
|------|------|
| `python3 cookie_manager.py check` | 检查cookie是否有效 |
| `python3 cookie_manager.py save "<cookie>"` | 保存cookie |
| `python3 cookie_manager.py delete` | 清除cookie（重新登录用） |
| `python3 cookie_manager.py meta` | 查看cookie元信息 |

Cookie存储位置：
- `/root/.openclaw/workspace/baijiahao-cookies.json` - cookie数据
- `/root/.openclaw/state/baijiahao-cookies-meta.json` - 元信息

## 百家号发布参数说明

| 参数 | 说明 | 要求 |
|------|------|------|
| title | 文章标题 | ≤30字，建议20-28字 |
| content | 正文内容 | 支持HTML/Markdown，建议1500-3000字 |
| cover_image | 封面图路径 | JPG/PNG，建议900x500 |
| category | 文章分类 | 企业服务/科技/财经等 |
| tags | 文章标签 | 3-5个，用逗号分隔 |
| cover_type | 封面类型 | single（单图）/ triple（三图）/ large（大图） |

## 常见问题处理

| 问题 | 解决方案 |
|------|----------|
| 登录二维码过期 | 刷新登录页重新生成 |
| Cookie注入失败 | 重新扫码登录 |
| 找不到标题/正文输入框 | 截图发给用户，手动完成 |
| 发布按钮点击无反应 | 检查是否有未填写的必填项 |
| 验证码/安全验证 | 截图发给用户手动完成 |
| 图片上传失败 | 检查图片格式和大小（≤5MB） |

## 注意事项

- 百家号无公开发布API，只能走浏览器自动化
- 页面UI更新可能导致元素选择器失效，需截图调试
- Cookie有效期约30天，过期后需重新扫码
- 建议发布前先预览检查格式
- 百家号对内容审核较严，避免敏感词

## 手动发布方案（浏览器不可用时）

当浏览器不可用时，引导用户手动发布：

1. 整理好内容和标题
2. 提示用户访问：https://baijiahao.baidu.com/builder/content/publish
3. 将内容格式化后发送给用户（HTML或Markdown）
4. 用户手动粘贴发布

导出内容供本地使用：
```bash
cat > /root/.openclaw/workspace/baijiahao_article.html << 'EOF'
<文章HTML内容>
EOF
```
