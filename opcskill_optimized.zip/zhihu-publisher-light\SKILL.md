---
name: zhihu-publisher
description: "知乎自动发布工具（轻量版），使用Python脚本和系统Chrome浏览器，体积<25MB。支持自动发布文章和回答到知乎平台。使用场景包括：(1) 自动发布知乎文章，(2) 自动发布知乎回答，(3) 批量发布知乎内容，(4) 自动化知乎内容发布流程，(5) 集成知乎发布功能到工作流。"
---

# 知乎自动发布工具（轻量版）

轻量版知乎自动发布工具，使用 Python 脚本替代原 53MB 的 exe，体积从 232MB 优化至 <25MB。

## 快速开始

### 环境要求
- Windows 操作系统
- Python 3.8+
- Chrome 浏览器已安装
- ChromeDriver（已自动下载或手动配置）

### 安装依赖
```bash
pip install -r requirements.txt
```

### 基本使用

**发布文章：**
```bash
python zhihu_publisher.py --type article --title "我的文章标题" --content "文章内容..." --tags "技术,Python,知乎"
```

**从文件发布：**
```bash
python zhihu_publisher.py --type article --title "标题" --content-file "article.md"
```

**发布回答：**
```bash
python zhihu_publisher.py --type answer --question-url "https://www.zhihu.com/question/123456" --content "回答内容..."
```

**保存草稿：**
```bash
python zhihu_publisher.py --type article --title "草稿" --content "内容" --save-draft
```

### 命令行参数

| 参数 | 说明 | 必需 |
|------|------|------|
| `--type` | 发布类型：article/answer | 是 |
| `--title` | 文章标题 | article类型必需 |
| `--content` | 内容文本 | 否 |
| `--content-file` | 内容文件路径 | 否 |
| `--question-url` | 问题URL | answer类型必需 |
| `--tags` | 标签，逗号分隔 | 否 |
| `--save-draft` | 保存为草稿 | 否 |
| `--headless` | 无头模式 | 否 |
| `--cookies-file` | Cookie文件路径 | 否 |

## 登录流程

首次使用需要手动登录：
```bash
python zhihu_publisher.py --type article --title "测试" --content "测试内容"
```
程序会自动打开浏览器进行登录，登录成功后 Cookie 会保存到 `cookies.json`，后续使用无需重复登录。

## ChromeDriver 配置

脚本会自动下载匹配版本的 ChromeDriver。如果网络受限，可手动下载：

1. 访问 https://storage.googleapis.com/chrome-for-testing-public/
2. 下载匹配的 chromedriver-win64.zip
3. 解压 chromedriver.exe 到 C:\Windows\System32\ 或项目目录

## 代码集成

```python
from zhihu_publisher import ZhihuPublisher

publisher = ZhihuPublisher(headless=False)
publisher.setup_driver()

# 发布文章
publisher.publish_article(
    title="Python 入门教程",
    content="这是一篇 Python 入门教程...",
    tags=["Python", "教程", "编程"]
)

# 发布回答
publisher.publish_answer(
    question_url="https://www.zhihu.com/question/123456",
    content="我的回答内容..."
)

publisher.close()
```

## 优化说明

与原版对比：

| 项目 | 原版 | 轻量版 |
|------|------|--------|
| 体积 | 232MB | <25MB |
| 执行文件 | 53MB exe | 15KB Python |
| 浏览器 | 内置 Chromium | 系统 Chrome |
| 依赖 | 无 | Python 3.8+ |
| 可定制性 | 低 | 高（开源） |

## 故障排除

1. **找不到 Chrome**：设置环境变量 CHROME_PATH
2. **ChromeDriver 下载失败**：手动下载 Chromedriver
3. **Cookie 过期**：删除 cookies.json 重新登录
4. **发布超时**：增加等待时间或检查网络

## 文件结构

```
zhihu-publisher/
├── SKILL.md
└── assets/
    └── zhihu-publisher/
        ├── zhihu_publisher.py     # 主脚本
        ├── requirements.txt       # Python 依赖
        └── package.json           # 包信息
```

## 最佳实践

1. 首次先以非 headless 模式测试
2. 定期更新 Cookie 避免过期
3. 合理控制发布频率（建议 >30 分钟间隔）
4. 内容发布前做好审核
