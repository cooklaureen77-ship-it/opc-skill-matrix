---
name: opc-xhs-publisher
description: OPC孵化器专属小红书内容发布技能。自动读取文章文件，精简内容至1000字内，生成封面图，并发布到小红书。触发词：发布OPC文章、发布到小红书、OPC小红书发布、发布文章到小红书。适用于帝苏OPC项目的营销推广内容自动化发布。
---

# OPC小红书发布器

自动化完成从文章文件到小红书发布的完整流程。

## 执行流程

### Step 1：读取文章文件

支持格式：`.txt` 纯文本文件

从用户处获取文件路径，读取内容。若未提供路径，询问用户。

### Step 2：精简内容

小红书限制：标题≤20字，正文≤1000字。

精简策略（保留优先级）：
1. **核心信息**：产品名称、价格、效果数据
2. **结构化内容**：用 emoji + 短句保持可读性
3. **删除内容**：冗长描述、重复信息、过多示例

精简后检查字数：
```bash
python3 -c "import json; d=json.load(open('/tmp/publish_args.json')); print(f'Title: {len(d[\"title\"])} chars\nContent: {len(d[\"content\"])} chars')"
```

### Step 3：生成封面图

调用封面生成技能（disu1）生成小红书规格封面：

```bash
# 读取封面生成器配置
cat /root/.openclaw/workspace/skills/disu1/resources/config.json

# 生成提示词（风格：简约科技风）
PROMPT="OPC孵化器，产业咨询到AI落地，现代办公场景，简洁背景，蓝色主题，科技质感，高质量封面图"

# 调用生图API（通过本地代理）
curl -s -X POST "http://127.0.0.1:9800/images/generations" \
  -H "Content-Type: application/json" \
  -d "{\"model\":\"cogview-4\",\"prompt\":\"${PROMPT}\",\"size\":\"1080x1440\"}"
```

若本地代理未运行，使用 Pillow 生成备用封面：
```python
python3 << 'EOF'
from PIL import Image, ImageDraw, ImageFont
img = Image.new('RGB', (1080, 1440), color='#1a73e8')
draw = ImageDraw.Draw(img)
try:
    font = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf', 80)
except:
    font = ImageFont.load_default()
draw.text((540, 600), 'OPC孵化器', fill='white', font=font, anchor='mm')
img.save('/root/.openclaw/workspace/opc_cover.png')
EOF
```

### Step 4：登录状态管理与扫码登录

#### 4.1 检查登录状态

```bash
mcporter call xiaohongshu-mcp.check_login_status --output json
```

登录状态说明：
- ✅ 已登录：cookie 有效，可以直接发布
- ❌ 未登录：需要扫码，或 cookie 已失效

#### 4.2 Cookie 保存路径与复用机制

登录成功后，cookie 自动保存到：
```
/root/.openclaw/state/xiaohongshu-mcp/cookies.json
```

**复用规则：**
- 服务重启后，xiaohongshu-mcp 会自动读取该文件恢复登录态
- Cookie 有效期通常为 30-90 天（取决于小红书服务端）
- 若 cookie 失效，发布时会报错，需重新扫码

#### 4.3 扫码登录流程

当检测到未登录时，执行完整扫码流程：

```bash
# 1. 生成二维码
mcporter call xiaohongshu-mcp.get_login_qrcode --output json > /tmp/qr_result.json

# 2. 提取二维码图片数据并保存
cat /tmp/qr_result.json | jq -r '.content[] | select(.type=="image") | .data' | base64 -d > /root/.openclaw/workspace/xhs-login-qr.png

# 3. 提取有效期提示
cat /tmp/qr_result.json | jq -r '.content[] | select(.type=="text") | .text'
```

**发送给用户：**
- 使用 `lightclaw_upload_file` 上传二维码图片
- 提示用户用小红书 App 扫码（通常有效期 2-3 分钟）
- 等待用户确认扫码完成

#### 4.4 验证登录结果

用户扫码后，再次检查登录状态：
```bash
mcporter call xiaohongshu-mcp.check_login_status --output json
```

若仍显示未登录，可能是：
1. 二维码已过期 → 重新生成
2. 用户未成功扫码 → 提示重新扫码
3. Cookie 文件被清除 → 检查 `/root/.openclaw/state/xiaohongshu-mcp/cookies.json` 是否存在

#### 4.5 强制重新登录（可选）

若需要清除旧登录态重新登录：
```bash
mcporter call xiaohongshu-mcp.delete_cookies
# 之后按 4.3 流程重新扫码
```

### Step 5：发布到小红书

构建发布参数 JSON：
```json
{
  "title": "精简后的标题（≤20字）",
  "images": ["/root/.openclaw/workspace/opc_cover.png"],
  "content": "精简后的正文（≤1000字）",
  "tags": ["OPC孵化器", "帝苏OPC", "产业咨询", "AI数字化", "企业服务"]
}
```

执行发布：
```bash
mcporter call xiaohongshu-mcp.publish_content --args "$(cat /tmp/publish_args.json)"
```

### Step 6：验证发布结果

检查输出是否包含"发布完成"或"PostID"。

若失败，根据错误信息处理：
- **标题超长**：继续精简标题
- **正文超长**：继续精简正文
- **未找到发布TAB**：检查登录状态，重启服务

## 注意事项

- 小红书 cookie 保存在 `/root/.openclaw/state/xiaohongshu-mcp/cookies.json`
- 服务重启后需重新登录（扫码）
- 封面图默认保存到 `/root/.openclaw/workspace/opc_cover.png`
- 发布失败时可手动访问 https://creator.xiaohongshu.com 检查

## 常用命令速查

| 操作 | 命令 |
|------|------|
| 检查登录 | `mcporter call xiaohongshu-mcp.check_login_status` |
| 生成二维码 | `mcporter call xiaohongshu-mcp.get_login_qrcode` |
| 发布内容 | `mcporter call xiaohongshu-mcp.publish_content --args <json>` |
| 重启服务 | `kill $(cat /root/.openclaw/state/xiaohongshu-mcp/server.pid); xiaohongshu-mcp &` |
