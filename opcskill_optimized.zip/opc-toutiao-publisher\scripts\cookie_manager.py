#!/usr/bin/env python3
"""cookie manager for toutiao"""
import json, os, sys
from datetime import datetime
WK = os.environ.get("OPC_WORKSPACE", "/root/.openclaw/workspace")
ST = os.environ.get("OPC_STATE", "/root/.openclaw/state")
CF = os.path.join(WK, "toutiao-cookies.json")
MF = os.path.join(ST, "toutiao-cookies-meta.json")
def _ed(p):
    d = os.path.dirname(p)
    if d and not os.path.exists(d): os.makedirs(d)
def check():
    if not os.path.exists(CF): print("cookie not found"); return False
    with open(CF) as f: d = json.load(f)
    print("cookie ok, saved:", d.get("saved_at")); return True
def save(s):
    _ed(CF)
    with open(CF, "w") as f: json.dump({"cookie": s, "saved_at": datetime.now().isoformat()}, f, ensure_ascii=False)
    print("cookie saved")
def delete():
    for p in [CF, MF]:
        if os.path.exists(p): os.remove(p)
    print("cookie deleted")
if __name__ == "__main__":
    if len(sys.argv) < 2: print("Usage: check | save <value> | delete"); sys.exit(1)
    {"check": check, "save": lambda: save(sys.argv[2]) if len(sys.argv) > 2 else None, "delete": delete}.get(sys.argv[1], lambda: None)()
