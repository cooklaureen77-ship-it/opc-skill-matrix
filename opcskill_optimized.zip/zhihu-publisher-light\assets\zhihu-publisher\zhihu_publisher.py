#!/usr/bin/env python3
"""
知乎自动发布工具 - 轻量版
使用系统Chrome浏览器和Selenium进行自动化发布
"""

import os
import sys
import json
import time
import argparse
import logging
from pathlib import Path
from typing import Optional, Dict, List, Any

try:
    from selenium import webdriver
    from selenium.webdriver.common.by import By
    from selenium.webdriver.common.keys import Keys
    from selenium.webdriver.support.ui import WebDriverWait
    from selenium.webdriver.support import expected_conditions as EC
    from selenium.webdriver.chrome.service import Service
    from selenium.webdriver.chrome.options import Options
except ImportError:
    print("请先安装依赖: pip install selenium")
    sys.exit(1)

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

class ZhihuPublisher:
    """知乎发布器"""
    
    def __init__(self, headless: bool = False, cookies_file: str = "cookies.json"):
        """
        初始化发布器
        
        Args:
            headless: 是否使用无头模式
            cookies_file: Cookie文件路径
        """
        self.headless = headless
        self.cookies_file = Path(cookies_file)
        self.driver = None
        self.wait = None
        
        # 知乎URL
        self.base_url = "https://www.zhihu.com"
        self.login_url = f"{self.base_url}/signin"
        self.article_url = f"{self.base_url}/creator"
        self.answer_url = f"{self.base_url}/question/"
        
    def setup_driver(self):
        """设置Chrome驱动"""
        chrome_options = Options()
        
        if self.headless:
            chrome_options.add_argument("--headless")
        
        # 基本配置
        chrome_options.add_argument("--disable-blink-features=AutomationControlled")
        chrome_options.add_argument("--disable-dev-shm-usage")
        chrome_options.add_argument("--no-sandbox")
        chrome_options.add_argument("--disable-gpu")
        chrome_options.add_argument("--window-size=1920,1080")
        chrome_options.add_experimental_option("excludeSwitches", ["enable-automation"])
        chrome_options.add_experimental_option('useAutomationExtension', False)
        
        # 尝试找到Chrome路径
        chrome_paths = [
            "C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe",
            "C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe",
            os.environ.get("CHROME_PATH", ""),
        ]
        
        for path in chrome_paths:
            if path and Path(path).exists():
                chrome_options.binary_location = path
                break
        
        # ChromeDriver路径
        chromedriver_paths = [
            "chromedriver.exe",
            "C:\\Windows\\System32\\chromedriver.exe",
            os.environ.get("CHROMEDRIVER_PATH", ""),
        ]
        
        service = None
        for path in chromedriver_paths:
            if path and Path(path).exists():
                service = Service(executable_path=path)
                break
        
        if service is None:
            # 尝试从PATH查找
            service = Service()
        
        try:
            self.driver = webdriver.Chrome(service=service, options=chrome_options)
            self.wait = WebDriverWait(self.driver, 30)
            logger.info("Chrome驱动初始化成功")
        except Exception as e:
            logger.error(f"Chrome驱动初始化失败: {e}")
            raise
    
    def load_cookies(self) -> bool:
        """加载Cookie"""
        if not self.cookies_file.exists():
            logger.warning(f"Cookie文件不存在: {self.cookies_file}")
            return False
        
        try:
            with open(self.cookies_file, 'r', encoding='utf-8') as f:
                cookies = json.load(f)
            
            self.driver.get(self.base_url)
            for cookie in cookies:
                # 确保domain正确
                if 'domain' in cookie and cookie['domain'].startswith('.'):
                    cookie['domain'] = cookie['domain'][1:]
                try:
                    self.driver.add_cookie(cookie)
                except Exception as e:
                    logger.warning(f"添加Cookie失败: {e}")
            
            logger.info("Cookie加载成功")
            return True
        except Exception as e:
            logger.error(f"加载Cookie失败: {e}")
            return False
    
    def save_cookies(self):
        """保存Cookie"""
        try:
            cookies = self.driver.get_cookies()
            with open(self.cookies_file, 'w', encoding='utf-8') as f:
                json.dump(cookies, f, ensure_ascii=False, indent=2)
            logger.info(f"Cookie已保存到: {self.cookies_file}")
        except Exception as e:
            logger.error(f"保存Cookie失败: {e}")
    
    def login(self):
        """登录知乎（需要手动操作）"""
        logger.info("开始登录流程...")
        self.driver.get(self.login_url)
        
        print("=" * 50)
        print("请手动完成登录操作：")
        print("1. 在浏览器中输入账号密码登录")
        print("2. 完成所有验证（如需要）")
        print("3. 登录成功后，在此按Enter键继续...")
        print("=" * 50)
        
        input("按Enter键继续...")
        
        # 验证登录是否成功
        self.driver.get(self.base_url)
        time.sleep(3)
        
        # 检查登录状态
        if "signin" not in self.driver.current_url:
            self.save_cookies()
            logger.info("登录成功")
            return True
        else:
            logger.error("登录失败，请检查")
            return False
    
    def ensure_login(self):
        """确保已登录"""
        if self.load_cookies():
            self.driver.get(self.base_url)
            time.sleep(2)
            
            # 检查是否仍在登录页面
            if "signin" in self.driver.current_url:
                logger.info("Cookie已过期，需要重新登录")
                return self.login()
            return True
        else:
            return self.login()
    
    def publish_article(self, title: str, content: str, tags: List[str] = None, 
                       save_draft: bool = False) -> bool:
        """
        发布文章
        
        Args:
            title: 文章标题
            content: 文章内容
            tags: 标签列表
            save_draft: 是否保存为草稿
            
        Returns:
            是否发布成功
        """
        try:
            if not self.ensure_login():
                return False
            
            logger.info(f"开始发布文章: {title}")
            
            # 进入创作中心
            self.driver.get(self.article_url)
            time.sleep(3)
            
            # 点击"写文章"按钮
            try:
                write_btn = self.wait.until(
                    EC.element_to_be_clickable((By.XPATH, "//button[contains(text(), '写文章')]"))
                )
                write_btn.click()
                time.sleep(2)
            except:
                # 尝试其他选择器
                try:
                    write_btn = self.driver.find_element(By.CSS_SELECTOR, ".CreatorButton")
                    write_btn.click()
                    time.sleep(2)
                except:
                    logger.error("找不到'写文章'按钮")
                    return False
            
            # 等待编辑器加载
            time.sleep(3)
            
            # 输入标题
            try:
                title_input = self.wait.until(
                    EC.presence_of_element_located((By.CSS_SELECTOR, ".DraftEditor-titleInput"))
                )
                title_input.clear()
                title_input.send_keys(title)
                logger.info("标题输入完成")
            except:
                logger.warning("标题输入失败，尝试继续")
            
            # 输入内容
            try:
                content_area = self.wait.until(
                    EC.presence_of_element_located((By.CSS_SELECTOR, ".DraftEditor-editorContainer"))
                )
                content_area.click()
                
                # 使用JavaScript直接设置内容
                self.driver.execute_script(f"""
                    var editor = document.querySelector('.public-DraftEditor-content');
                    if (editor) {{
                        editor.focus();
                        document.execCommand('insertText', false, arguments[0]);
                    }}
                """, content)
                logger.info("内容输入完成")
            except:
                logger.warning("内容输入失败，尝试备用方法")
                # 备用方法：直接发送键盘输入
                content_area = self.driver.find_element(By.CSS_SELECTOR, ".public-DraftEditor-content")
                content_area.send_keys(content)
            
            # 添加标签
            if tags:
                try:
                    tags_input = self.driver.find_element(By.CSS_SELECTOR, ".TopicInput input")
                    for tag in tags[:5]:  # 最多5个标签
                        tags_input.send_keys(tag)
                        time.sleep(1)
                        tags_input.send_keys(Keys.ENTER)
                        time.sleep(1)
                    logger.info(f"标签添加完成: {tags}")
                except:
                    logger.warning("标签添加失败")
            
            # 保存或发布
            if save_draft:
                try:
                    save_btn = self.driver.find_element(By.XPATH, "//button[contains(text(), '保存草稿')]")
                    save_btn.click()
                    logger.info("已保存为草稿")
                except:
                    logger.error("保存草稿失败")
                    return False
            else:
                try:
                    publish_btn = self.driver.find_element(By.XPATH, "//button[contains(text(), '发布')]")
                    publish_btn.click()
                    time.sleep(2)
                    
                    # 确认发布
                    confirm_btn = self.driver.find_element(By.XPATH, "//button[contains(text(), '确认发布')]")
                    confirm_btn.click()
                    logger.info("文章发布成功")
                except:
                    logger.error("发布失败")
                    return False
            
            time.sleep(3)
            return True
            
        except Exception as e:
            logger.error(f"发布文章时出错: {e}")
            return False
    
    def publish_answer(self, question_url: str, content: str) -> bool:
        """
        发布回答
        
        Args:
            question_url: 问题URL
            content: 回答内容
            
        Returns:
            是否发布成功
        """
        try:
            if not self.ensure_login():
                return False
            
            logger.info(f"开始发布回答: {question_url}")
            
            # 访问问题页面
            self.driver.get(question_url)
            time.sleep(3)
            
            # 找到回答输入框
            try:
                answer_input = self.wait.until(
                    EC.presence_of_element_located((By.CSS_SELECTOR, ".RichText-Root"))
                )
                answer_input.click()
                answer_input.send_keys(content)
                logger.info("回答内容输入完成")
            except:
                logger.error("找不到回答输入框")
                return False
            
            # 提交回答
            try:
                submit_btn = self.wait.until(
                    EC.element_to_be_clickable((By.XPATH, "//button[contains(text(), '发布回答')]"))
                )
                submit_btn.click()
                logger.info("回答发布成功")
            except:
                logger.error("发布回答失败")
                return False
            
            time.sleep(3)
            return True
            
        except Exception as e:
            logger.error(f"发布回答时出错: {e}")
            return False
    
    def close(self):
        """关闭驱动"""
        if self.driver:
            self.driver.quit()
            logger.info("浏览器已关闭")

def main():
    """主函数"""
    parser = argparse.ArgumentParser(description="知乎自动发布工具")
    parser.add_argument("--type", choices=["article", "answer"], required=True, help="发布类型")
    parser.add_argument("--title", help="文章标题")
    parser.add_argument("--content", help="内容或内容文件路径")
    parser.add_argument("--content-file", help="内容文件路径")
    parser.add_argument("--tags", help="标签，用逗号分隔")
    parser.add_argument("--question-url", help="问题URL（回答类型需要）")
    parser.add_argument("--save-draft", action="store_true", help="保存为草稿")
    parser.add_argument("--headless", action="store_true", help="无头模式")
    parser.add_argument("--cookies-file", default="cookies.json", help="Cookie文件路径")
    parser.add_argument("--config", help="配置文件路径")
    
    args = parser.parse_args()
    
    # 读取内容
    content = ""
    if args.content:
        content = args.content
    elif args.content_file:
        try:
            with open(args.content_file, 'r', encoding='utf-8') as f:
                content = f.read()
        except Exception as e:
            logger.error(f"读取内容文件失败: {e}")
            sys.exit(1)
    
    # 解析标签
    tags = []
    if args.tags:
        tags = [tag.strip() for tag in args.tags.split(",")]
    
    # 创建发布器
    publisher = ZhihuPublisher(
        headless=args.headless,
        cookies_file=args.cookies_file
    )
    
    try:
        publisher.setup_driver()
        
        if args.type == "article":
            if not args.title:
                logger.error("发布文章需要--title参数")
                sys.exit(1)
            
            success = publisher.publish_article(
                title=args.title,
                content=content,
                tags=tags,
                save_draft=args.save_draft
            )
            
            if success:
                logger.info("文章发布完成")
            else:
                logger.error("文章发布失败")
                sys.exit(1)
                
        elif args.type == "answer":
            if not args.question_url:
                logger.error("发布回答需要--question-url参数")
                sys.exit(1)
            
            success = publisher.publish_answer(
                question_url=args.question_url,
                content=content
            )
            
            if success:
                logger.info("回答发布完成")
            else:
                logger.error("回答发布失败")
                sys.exit(1)
    
    except KeyboardInterrupt:
        logger.info("用户中断操作")
    except Exception as e:
        logger.error(f"程序执行出错: {e}")
        sys.exit(1)
    finally:
        publisher.close()

if __name__ == "__main__":
    main()