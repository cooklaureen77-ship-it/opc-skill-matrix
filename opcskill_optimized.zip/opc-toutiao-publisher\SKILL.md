---
name: opc-toutiao-publisher
description: OPC孵化器专属今日头条（头条号）内容发布技能。自动读取文章文件，适配头条号内容格式，生成封面图，并发布到头条号。触发词：发布到头条、今日头条发布、头条号发布、OPC头条发布、发布文章到头条。适用于帝苏OPC项目的营销推广内容自动化发布到字节跳动内容生态。
---

# OPC今日头条发布器

自动化完成从文章文件到今日头条（头条号）发布的完整流程。

## 执行流程

### Step 1：读取文章文件

支持格式：`.txt` 或 `.md` 文件

从用户处获取文件路径，读取内容。若未提供路径，询问用户。

### Step 2：内容适配

今日头条要求：
- 标题：≤30字（建议22-28字，利于推荐算法）
- 正文：建议1000-3000字，支持富文本格式
- 封面图：建议尺寸 1200x750（16:9）
- 分类：需选择频道类别（科技/财经/教育等）

**内容优化策略（头条SEO+推荐算法优化）：**
1. **标题优化**：使用数字、疑问句、悬念式，提高点击率
2. **开头钩子**：前100字抓住读者注意力
3. **信息增量**：提供实用信息、数据支撑
4. **段落结构**：短段落 + 小标题 + 图文混排
5. **互动引导**：结尾设置引导评论、收藏的CTA

头条内容格式参考：
```
标题：OPC孵化器一站式服务，从咨询到落地的完整指南

正文：
【设置悬念/抛出问题】
创业公司最怕什么？不是没钱，是方向错了...

【核心干货】
本文从三个维度解析OPC孵化器的完整产品矩阵...

【互动引导】
你觉得创业过程中最需要哪种服务？评论区聊聊👇
```

检查格式：
```bash
python3 /root/.openclaw/workspace/skills/opc-toutiao-publisher/scripts/format_content.py \
  --platform toutiao /path/to/article.txt
```

### Step 3：生成封面图

调用封面生成技能生成头条规格封面：

```bash
# 头条封面尺寸：1200x750（16:9比例）
python3 /root/.openclaw/workspace/skills/opc-toutiao-publisher/scripts/generate_cover.py \
  "OPC孵化器" "从咨询到AI落地" /root/.openclaw/workspace/opc_toutiao_cover.png
```

Pillow备用方案：
```python
python3 << 'EOF'
from PIL import Image, ImageDraw, ImageFont
img = Image.new('RGB', (1200, 750), color='#ff6b35')
draw = ImageDraw.Draw(img)
try:
    font = ImageFont.truetype('/usr/share/fonts/truetype/wqy/wqy-zenhei.ttc', 72)
except:
    font = ImageFont.load_default()
draw.text((600, 320), 'OPC孵化器', fill='white', font=font, anchor='mm')
draw.text((600, 400), '从产业咨询到AI落地的完整方案', fill='#f0f0f0', font=font, anchor='mm')
img.save('/root/.openclaw/workspace/opc_toutiao_cover.png')
EOF
```

### Step 4：登录状态管理

#### 4.1 检查登录状态

```bash
python3 /root/.openclaw/workspace/skills/opc-toutiao-publisher/scripts/cookie_manager.py check
```

#### 4.2 扫码登录

**浏览器自动化方式：**
```bash
# 导航到头条号登录
browser action=navigate, url="https://mp.toutiao.com", target=host

# 截图二维码
browser action=screenshot, target=host
```

**引导用户扫码：** 使用抖音/今日头条App扫码

轮询检查登录：
```bash
# 检查URL或页面元素
browser action=snapshot, target=host
```

#### 4.3 保存Cookie

```bash
python3 /root/.openclaw/workspace/skills/opc-toutiao-publisher/scripts/cookie_manager.py save "$(browser action=act, kind=evaluate, fn='document.cookie', target=host)"
```

### Step 5：发布到头条号

**浏览器自动化发布流程：**

```bash
# 1. 进入发布页面
browser action=navigate, url="https://mp.toutiao.com/profile_v4/graphic/publish", target=host

# 2. 输入标题
browser action=act, kind=click, ref="标题输入框", target=host
browser action=act, kind=type, text="文章标题", target=host

# 3. 输入正文（切换到编辑器模式）
browser action=act, kind=click, ref="正文编辑区", target=host
browser action=act, kind=type, text="$(cat /tmp/toutiao_content.txt)", target=host

# 4. 上传封面图
browser action=act, kind=click, ref="上传封面", target=host

# 5. 选择频道分类
browser action=act, kind=click, ref="频道选择", target=host
browser action=act, kind=click, ref="科技", target=host

# 6. 添加标签（可选）
browser action=act, kind=click, ref="添加标签", target=host
browser action=act, kind=type, text="OPC孵化器", target=host

# 7. 发布
browser action=act, kind=click, ref="发布", target=host
```

### Step 6：验证发布结果

```bash
# 检查发布结果
browser action=snapshot, target=host
# 获取文章URL
browser action=act, kind=evaluate, fn="window.location.href", target=host
```

## Cookie管理脚本

使用 `scripts/cookie_manager.py` 管理登录态：

| 命令 | 功能 |
|------|------|
| `python3 cookie_manager.py check` | 检查cookie是否有效 |
| `python3 cookie_manager.py save "<cookie>"` | 保存cookie |
| `python3 cookie_manager.py delete` | 清除cookie（重新登录用） |
| `python3 cookie_manager.py meta` | 查看cookie元信息 |

Cookie存储位置：
- `/root/.openclaw/workspace/toutiao-cookies.json` - cookie数据
- `/root/.openclaw/state/toutiao-cookies-meta.json` - 元信息

## 头条号内容格式指南

| 要素 | 建议 | 说明 |
|------|------|------|
| 标题 | 22-28字 | 含数字、疑问或悬念，提升点击率 |
| 开头 | 前100字 | 抛出问题或核心观点，抓住注意力 |
| 正文 | 1000-3000字 | 短段落+小标题，建议每段≤200字 |
| 配图 | 每500-800字配一张 | 提升阅读体验和完读率 |
| 结尾 | 50-100字 | 引导互动：评论区聊聊，关注获取更多 |

## 推荐算法优化建议

1. **标题含关键词**：OPC、孵化器、创业、数字化
2. **内容原创度**：头条对原创内容有加权推荐
3. **互动率**：引导评论、收藏、转发
4. **阅读完成率**：内容长度控制在2000字以内，保证完读率
5. **发布时间**：建议工作日 8:00-10:00 或 18:00-21:00 发布

## 常见问题处理

| 问题 | 解决方案 |
|------|----------|
| 头条号未注册 | 引导用户先注册头条号（https://mp.toutiao.com） |
| 账号等级限制 | 新手号每天发布数量有限，注意控制频率 |
| 图片上传失败 | 检查图片格式（JPG/PNG）和大小（≤10MB） |
| 内容被判定为广告 | 减少营销用语，增加干货内容比例 |
| 推荐量低 | 优化标题和封面，选择高热频道分类 |

## 手动发布方案（浏览器不可用时）

```bash
# 导出内容供用户手动发布
cat > /root/.openclaw/workspace/toutiao_article.txt << 'EOF'
<头条优化版内容>
EOF
```

提示用户：
1. 访问：https://mp.toutiao.com/profile_v4/graphic/publish
2. 注册或登录头条号
3. 复制粘贴内容发布

## 注意事项

- 头条号审核机制较严格，营销内容可能会被限制推荐
- 建议将营销内容包装为行业干货，降低广告感
- 头条号每天发布次数有限制，根据账号等级不同
- 发布后15分钟是推荐量验证期，不要反复修改
- 首次使用建议先在头条App注册开通头条号
