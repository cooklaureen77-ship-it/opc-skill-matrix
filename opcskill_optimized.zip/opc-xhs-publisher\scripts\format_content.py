#!/usr/bin/env python3
"""OPC文章内容精简器 - 将长文章精简为小红书格式"""

import re
import sys
import json

def read_file(path):
    with open(path, 'r', encoding='utf-8') as f:
        return f.read()

def strip_title_line(text):
    """移除常见的标题行如 '文章15：《xxx》' """
    lines = text.split('\n')
    cleaned = []
    for line in lines:
        line = line.strip()
        if re.match(r'^文章\d+[：:].+$', line):
            continue
        cleaned.append(line)
    return '\n'.join(cleaned)

def extract_core_content(text):
    """提取核心内容，移除冗余"""
    # 去掉分隔线之类
    text = re.sub(r'^-{3,}', '', text)
    text = re.sub(r'^={3,}', '', text)
    return text.strip()

def build_publish_json(title, content, cover_path, tags, schedule_at=None):
    """构建发布用的JSON"""
    data = {
        "title": title,
        "images": [cover_path],
        "content": content,
        "tags": tags
    }
    if schedule_at:
        data["schedule_at"] = schedule_at
    return json.dumps(data, ensure_ascii=False, indent=2)

def check_length(data_json):
    """检查标题和正文长度"""
    d = json.loads(data_json)
    title_len = len(d["title"])
    content_len = len(d["content"])
    return {
        "title": title_len,
        "content": content_len,
        "title_ok": title_len <= 20,
        "content_ok": content_len <= 1000,
        "data": d
    }

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: format_content.py <text_file> [title]")
        sys.exit(1)

    text = read_file(sys.argv[1])
    text = strip_title_line(text)
    text = extract_core_content(text)

    print("=== 精简后内容 ===")
    print(text)
    print(f"\n=== 字数: {len(text)} ===")
