#!/usr/bin/env python3
"""cover generator"""
import os, sys
from PIL import Image, ImageDraw, ImageFont
def _f(sz):
    for p in ["/usr/share/fonts/truetype/wqy/wqy-zenhei.ttc",
              "/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc",
              "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"]:
        if os.path.exists(p):
            try: return ImageFont.truetype(p, sz)
            except: pass
    return ImageFont.load_default()
def g(title, sub='', out=None):
    im = Image.new('RGB', (1080, 1440), color='#1a73e8')
    d = ImageDraw.Draw(im)
    ft = _f(60 if len(title) <= 10 else 45)
    fs = _f(35)
    d.text((1080//2, 1440//2), title, fill='white', font=ft, anchor='mm')
    if sub: d.text((1080//2, 1440//2 + 60), sub, fill='#e8e8e8', font=fs, anchor='mm')
    if not out: out = os.path.join(os.environ.get('OPC_WORKSPACE', '/root/.openclaw/workspace'), 'opc_cover.png')
    os.makedirs(os.path.dirname(out), exist_ok=True)
    im.save(out)
    print('saved:', out)
    return out
if __name__ == "__main__":
    g(sys.argv[1] if len(sys.argv) > 1 else "OPC", sys.argv[2] if len(sys.argv) > 2 else "")
