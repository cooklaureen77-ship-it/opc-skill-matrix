#!/usr/bin/env python3
"""OPC文章内容适配百家号格式"""

import re
import sys
import json
import argparse


def read_file(path):
    with open(path, 'r', encoding='utf-8') as f:
        return f.read()


def extract_title(text):
    """从文章中提取或生成标题"""
    lines = text.split('\n')
    for line in lines:
        line = line.strip()
        if line.startswith('# ') or line.startswith('## '):
            return line.lstrip('#').strip()
    # 如果没有标题，用第一行
    for line in lines:
        if line.strip():
            return line.strip()[:30]
    return "OPC孵化器产品矩阵详解"


def format_for_baijiahao(text, max_title=30, target_length=2000):
    """
    适配百家号格式
    - 标题≤30字
    - 正文建议1500-3000字
    - 增加SEO关键词
    """
    # 清理格式标记
    text = re.sub(r'^文章\d+[：:].+$', '', text, flags=re.MULTILINE)
    text = re.sub(r'^#{1,6}\s+', '', text, flags=re.MULTILINE)
    text = re.sub(r'\*{2,}', '', text)
    text = re.sub(r'`{1,3}[^`]+`{1,3}', lambda m: m.group(0).strip('`'), text)

    # 提取标题
    title = extract_title(text)
    if len(title) > max_title:
        title = title[:max_title]

    # 优化正文
    lines = [l.strip() for l in text.split('\n') if l.strip()]
    content = '\n\n'.join(lines)

    # 添加SEO优化（百家号专用）
    seo_intro = "【OPC孵化器】帝苏OPC孵化器提供从产业咨询到AI落地的完整解决方案，帮助创业者实现数字化转型。\n\n"
    seo_tags = "\n\n---\n\n相关标签：#OPC孵化器 #产业咨询 #AI数字化 #企业服务 #创业孵化"

    if len(content) < target_length:
        final_content = seo_intro + content + seo_tags
    else:
        final_content = seo_intro + content[:target_length-len(seo_intro+seo_tags)] + seo_tags

    return title, final_content


def build_publish_json(title, content, cover_path, category="企业服务", tags=None):
    """构建百家号发布参数"""
    if tags is None:
        tags = ["OPC孵化器", "产业咨询", "AI数字化", "企业服务"]

    data = {
        "title": title,
        "content": content,
        "cover_image": cover_path,
        "category": category,
        "tags": tags,
        "cover_type": "single"  # single/triple/large
    }
    return json.dumps(data, ensure_ascii=False, indent=2)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='适配百家号格式')
    parser.add_argument('input_file', help='输入文件路径')
    parser.add_argument('--output', '-o', help='输出JSON文件路径', default='/tmp/baijiahao_publish.json')
    parser.add_argument('--platform', default='baijiahao', help='目标平台')
    args = parser.parse_args()

    text = read_file(args.input_file)
    title, content = format_for_baijiahao(text)

    print(f"=== 标题 ({len(title)}字) ===")
    print(title)
    print(f"\n=== 正文 ({len(content)}字) ===")
    print(content[:200] + "...")

    # 构建发布参数
    publish_json = build_publish_json(title, content, "/root/.openclaw/workspace/opc_baijiahao_cover.png")
    with open(args.output, 'w', encoding='utf-8') as f:
        f.write(publish_json)
    print(f"\n✅ 发布参数已保存到: {args.output}")
