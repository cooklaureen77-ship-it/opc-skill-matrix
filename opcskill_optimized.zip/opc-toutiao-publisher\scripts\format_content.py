#!/usr/bin/env python3
"""OPC文章内容适配今日头条格式（含头条SEO优化）"""

import re
import sys
import json
import argparse


def read_file(path):
    with open(path, 'r', encoding='utf-8') as f:
        return f.read()


def extract_title(text):
    """从文章中提取标题"""
    lines = text.split('\n')
    for line in lines:
        line = line.strip()
        if line.startswith('# ') or line.startswith('## '):
            return line.lstrip('#').strip()
    for line in lines:
        if line.strip():
            return line.strip()[:30]
    return "OPC孵化器：从产业咨询到AI落地的完整方案"


def format_for_toutiao(text, max_title=28, target_length=2000):
    """
    适配今日头条格式，优化推荐算法友好度
    - 标题≤28字，含数字/悬念词
    - 正文1000-3000字
    - 前100字钩子
    - 短段落+小标题
    """
    text = re.sub(r'^文章\d+[：:].+$', '', text, flags=re.MULTILINE)
    text = re.sub(r'^#{3,6}\s+', '▎', text, flags=re.MULTILINE)  # 三级标题用▎
    text = re.sub(r'^#{1,2}\s+', '', text, flags=re.MULTILINE)
    text = re.sub(r'\*{2,}', '', text)
    text = re.sub(r'`{1,3}[^`]+`{1,3}', lambda m: m.group(0).strip('`'), text)

    # 提取并优化标题
    title = extract_title(text)
    if len(title) > max_title:
        title = title[:max_title]
    # 头条推荐优化：括号加数字或疑问
    if not any(c in title for c in ['？', '！', '多少', '如何', '揭秘']):
        title += "｜你知道吗？"

    # 整理正文 - 短段落处理
    lines = []
    for line in text.split('\n'):
        line = line.strip()
        if not line:
            continue
        # 把长段落拆分成短段
        if len(line) > 200 and '。' in line:
            parts = line.split('。')
            for part in parts:
                part = part.strip()
                if part:
                    lines.append(part + '。')
        else:
            lines.append(line)

    # 头条强化开头钩子
    hook = "创业公司最怕什么？不是没有好产品，而是方向错了、钱烧完了、团队散了。帝苏OPC孵化器创始人给出的答案是：缺的不是能力，是一套从战略到落地的完整体系。\n\n"
    
    # 加入互动引导结尾
    cta = "\n\n【互动话题】你觉得创业过程中最需要哪种服务？评论区聊聊你的想法👇\n关注@帝苏OPC 获取更多创业干货和数字化解决方案。"
    
    content = '\n\n'.join(lines)
    
    if len(content) < target_length:
        final_content = hook + content + cta
    else:
        final_content = hook + content[:target_length-len(hook+cta)] + cta

    return title, final_content


def build_publish_json(title, content, cover_path, category="科技", tags=None):
    """构建头条发布参数"""
    if tags is None:
        tags = ["OPC孵化器", "创业干货", "AI数字化", "企业服务"]
    
    data = {
        "title": title,
        "content": content,
        "cover_image": cover_path,
        "category": category,
        "tags": tags
    }
    return json.dumps(data, ensure_ascii=False, indent=2)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='适配今日头条格式')
    parser.add_argument('input_file', help='输入文件路径')
    parser.add_argument('--output', '-o', help='输出JSON文件路径', default='/tmp/toutiao_publish.json')
    parser.add_argument('--platform', default='toutiao', help='目标平台')
    args = parser.parse_args()

    text = read_file(args.input_file)
    title, content = format_for_toutiao(text)

    print(f"=== 标题 ({len(title)}字) ===")
    print(title)
    print(f"\n=== 正文 ({len(content)}字) ===")
    print(content[:200] + "...")

    # 构建发布参数
    publish_json = build_publish_json(title, content, "/root/.openclaw/workspace/opc_toutiao_cover.png")
    with open(args.output, 'w', encoding='utf-8') as f:
        f.write(publish_json)
    print(f"\n✅ 发布参数已保存到: {args.output}")
